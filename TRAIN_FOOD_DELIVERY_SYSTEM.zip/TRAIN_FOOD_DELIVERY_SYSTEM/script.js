document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll("button");
    buttons.forEach(button => {
        button.addEventListener("mouseenter", () => {
            button.style.backgroundColor = "#005f73";
        });
        button.addEventListener("mouseleave", () => {
            button.style.backgroundColor = "";
        });
    });
});
